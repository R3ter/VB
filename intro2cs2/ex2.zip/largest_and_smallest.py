
def largest_and_smallest(num1,num2,num3): # the first one is to check that an error is not given if all numbers were equal, the second one to check if the function works on negative numbers too.
    list = [num1,num2,num3]
    min = num3
    max = num3

    for i in list:
        if i < min:
            min = i
        if i > max:
            max = i   

         
                 
    return max,min


def check_largest_and_smallest():
    test1=largest_and_smallest(17,1,6)
    test2=largest_and_smallest(1,17,6)
    test3=largest_and_smallest(1,1,2)
    test4=largest_and_smallest(23,23,23)
    test5=largest_and_smallest(-1,0,-13)
    if test1 == (17,1) and test2 == (17,1) and test3 == (2,1) and test4==(23,23) and test5 == (0,-13):
        return True
    else:
        return False    
   



