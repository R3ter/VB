def calculate_mathematical_expression(num,float_num,operator):
    if operator == '+':
        return num + float_num
    elif operator == '-':
        return num - float_num
    elif operator == '*':
        return num*float_num
    elif operator == ':' and float_num>0:
        return float(num/float_num)
    return None                


def calculate_from_string(operation):
    x = operation.split(" ")
    return calculate_mathematical_expression(float(x[0]), float(x[2]), x[1])




