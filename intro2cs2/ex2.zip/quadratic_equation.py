import math
def quadratic_equation(a,b,c):
    formula = (b**2)-(4*a*c)
    if formula < 0:
        return None, None

    x1 = (-b + math.sqrt(formula))/2*a
    x2 = (-b - math.sqrt(formula))/2*a
    if x1 == x2:
        return x1, None
    return x1, x2   


def quadratic_equation_user_input():
    a,b,c = input("Insert coefficients a, b, and c: ").split(" ")
    
    if float(a) == 0:
        print("The parameter 'a' may not equal 0")
        return
    x1,x2=quadratic_equation(float(a),float(b),float(c))
    if x1 != None and x2 != None:
        print(f"The equation has 2 solutions: {x1} and {x2}")
    elif x1 != None and x2 == None: 
        print(f"The equation has 1 solution: {x1}") 
    elif x1 == None:
         print("The equation has no solutions")  

