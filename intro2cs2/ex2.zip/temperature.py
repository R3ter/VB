def is_vormir_safe(temp,temp1,temp2,temp3):
    if (temp1 > temp and temp2 > temp) or (temp1 > temp and temp3 > temp) or (temp2 > temp and temp3 > temp):
        return True
    else:
        return False
