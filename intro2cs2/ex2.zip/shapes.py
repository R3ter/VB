import math
def shape_area():
    x = input("Choose shape (1=circle, 2=rectangle, 3=triangle): ")
    if x == "1":
        y = float(input())
        area = y**2*math.pi
        return area
    elif x=="2":
        y = float(input())
        z = float(input())
        area = y*z
        return area
    elif x=="3":
        y = float(input())
        area = (math.sqrt(3)/4)*y**2
        return area
    else:
        return None 
              

